﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace estudio
{
    class Turma
    {

        private String Professor, dia_semana, hora;
        private int modalidade;

        public Turma()
        {

        }

        public Turma(int modalidade)
        {
            Modalidade = modalidade;
        }

        public Turma(string dia_semana, int modalidade)
        {
            Dia_semana = dia_semana;
            Modalidade = modalidade;
        }

        public Turma(string professor1, string dia_semana, string hora, int modalidade)
        {
            Professor1 = professor1;
            Dia_semana = dia_semana;
            Hora = hora;
            Modalidade = modalidade;
        }


        public string Professor1 { get => Professor; set => Professor = value; }
        public string Dia_semana { get => dia_semana; set => dia_semana = value; }
        public string Hora { get => hora; set => hora = value; }
        public int Modalidade { get => modalidade; set => modalidade = value; }

        public bool cadastrarTurma()
        {
            bool cad = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand insere = new MySqlCommand("insert into Estudio_Turma (IdModalidade, professorTurma, diaSemanaTurma, horaTurma)" + "values ('" + modalidade + "', '" + Professor + "', '" + dia_semana + "', '" + hora + "')", DAO_Conexao.con);
                insere.ExecuteNonQuery();
                cad = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return cad;
        }

        public bool excluirTurma()
        {
            bool excluiu = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand exclusao = new MySqlCommand("DELETE from Estudio_Turma WHERE IdModalidade = '" + modalidade + "'", DAO_Conexao.con);
                exclusao.ExecuteNonQuery();
                excluiu = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return excluiu;
        }

        public MySqlDataReader consultarTurma()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("SELECT * FROM Estudio_Turma WHERE IdModalidade =" + modalidade + "", DAO_Conexao.con);
                resultado = consulta.ExecuteReader();
                return resultado;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return resultado;
        }

        public MySqlDataReader consultarTurma01()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("SELECT * FROM Estudio_Turma WHERE IdModalidade =" + modalidade + " AND diaSemanaTurma = '" + dia_semana + "'", DAO_Conexao.con);
                resultado = consulta.ExecuteReader();
                return resultado;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return resultado;
        }
    }
}
