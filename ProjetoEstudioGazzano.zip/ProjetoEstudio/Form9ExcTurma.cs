﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estudio
{
    public partial class Form9ExcTurma : Form
    {
        int id;

        public Form9ExcTurma()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            
            Modalidade con_mod = new Modalidade();
            MySqlDataReader r = con_mod.consultarTodasModalidade();
            while (r.Read())
                comboBox1.Items.Add(r["descricaoModalidade"].ToString());
            DAO_Conexao.con.Close();
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            Modalidade mod = new Modalidade(comboBox1.Text);
            MySqlDataReader r = mod.consultarModalidade();
            if (r.Read())
            {
                id = Convert.ToInt32(r["idEstudio_Modalidade"].ToString());
            }
            DAO_Conexao.con.Close();
            Turma tur = new Turma(id);
            MySqlDataReader r2 = tur.consultarTurma();
            if (r2.Read())
            {
                comboBox2.Items.Add(r2["DiaSemanaTurma"].ToString());
            }
            DAO_Conexao.con.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedValueChanged(object sender, EventArgs e)
        {
            Turma tur2 = new Turma(comboBox2.Text,id);
            MySqlDataReader r3 = tur2.consultarTurma01();
            if (r3.Read())
            {
                comboBox3.Items.Add(r3["Hora_Turma"].ToString());
            }
            DAO_Conexao.con.Close();

        }
    }
}
