﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estudio
{
    public partial class estudio : Form
    {
        public estudio()
        {
            InitializeComponent();

            if (DAO_Conexao.getConexao("143.106.241.3", "cl201156", "cl201156", "1719"))
                Console.WriteLine("Conectado");
            else
                Console.WriteLine("Erro de Conexão");
        }

        private void Estúdio_Load(object sender, EventArgs e)
        {

        }


        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int tipo = DAO_Conexao.login(txtLogin.Text, txtSenha.Text);
            if (tipo == 0)
                MessageBox.Show("Usuário/Senha inválidos");
            if (tipo == 1)
            {
                MessageBox.Show("Usuário ADM");
                groupBox1.Visible = false;
                menuStrip1.Enabled = true;
            }
            if (tipo == 2)
            {
                MessageBox.Show("Usuário Restrito");
                groupBox1.Visible = false;
                menuStrip1.Enabled = true;
                cadastrarLoginToolStripMenuItem.Enabled = false;
                modalidadeToolStripMenuItem.Enabled = false;
            }
        }

        private void cadastrarLoginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3CadUsuario>().Count() ==0)
            {
                Form3CadUsuario cad_login = new Form3CadUsuario();
                cad_login.MdiParent = this;
                cad_login.Show();
            }

            
        }

        private void arquivoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void modalidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void cadastrarModalidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3CadUsuario>().Count() == 0)
            {
                Form4CadModalidade cad_modalidade = new Form4CadModalidade();
                cad_modalidade.MdiParent = this;
                cad_modalidade.Show();
            }
            
        }

        private void cadastrarAlunoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3CadUsuario>().Count() == 0)
            {
                Form2CadAluno cad_aluno = new Form2CadAluno();
                cad_aluno.MdiParent = this;
                cad_aluno.Show();
            }
            
        }

        private void excluirModalidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3CadUsuario>().Count() == 0)
            {
                Form5ExcModalidade exc_modalidade = new Form5ExcModalidade();
                exc_modalidade.MdiParent = this;
                exc_modalidade.Show();
            }
                
        }

        private void atualizarModalidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3CadUsuario>().Count() == 0)
            {
                Form6AtuModalidade atualizar_modalidade = new Form6AtuModalidade();
                atualizar_modalidade.MdiParent = this;
                atualizar_modalidade.Show();
            }
                
        }

        private void consultarModalidadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form3CadUsuario>().Count() == 0)
            {
                Form7ConsModalidade consultar_modalidade = new Form7ConsModalidade();
                consultar_modalidade.MdiParent = this;
                consultar_modalidade.Show();
            }
                
        }

        private void cadastrarTurmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form8CadTurma>().Count() == 0)
            {
                Form8CadTurma cadastrar_turma = new Form8CadTurma();
                cadastrar_turma.MdiParent = this;
                cadastrar_turma.Show();
            }
        }

        private void excluirTurmaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Form9ExcTurma>().Count() == 0)
            {
                Form9ExcTurma cadastrar_turma = new Form9ExcTurma();
                cadastrar_turma.MdiParent = this;
                cadastrar_turma.Show();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
