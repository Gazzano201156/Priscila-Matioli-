﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estudio
{
    public partial class Form8CadTurma : Form
    {
        int id;
        public Form8CadTurma()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            
            Modalidade con = new Modalidade();
            MySqlDataReader r = con.consultarTodasModalidade();
            while (r.Read())
            {
                comboBox1.Items.Add(r["descricaoModalidade"].ToString());
            
            }
            DAO_Conexao.con.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            Turma turma = new Turma(txtProfessor.Text, txtDiaSemana.Text, txtHora.Text, id);
            if (turma.cadastrarTurma())
                MessageBox.Show("Cadastrado com sucesso");
            else
                MessageBox.Show("Erro no cadastro");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        { 
            Modalidade mod = new Modalidade(comboBox1.Text);
            MySqlDataReader r = mod.consultarModalidade();
            if (r.Read())
            {
                id = Convert.ToInt32(r["idEstudio_Modalidade"].ToString());
            }
            DAO_Conexao.con.Close();
        }
    }
}
