﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estudio
{
    public partial class Form6AtuModalidade : Form
    {
        public Form6AtuModalidade()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Maximized;
            Modalidade cad = new Modalidade();
            MySqlDataReader r = cad.consultarTodasModalidade();
            while (r.Read())
                comboBox1.Items.Add(r["descricaoModalidade"].ToString());
            DAO_Conexao.con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Modalidade modalidade = new Modalidade(Convert.ToString(comboBox1.SelectedItem), float.Parse(txtPreco.Text), int.Parse(txtQtdeAl.Text), int.Parse(txtQtdeAu.Text));

            if (modalidade.atualizarModalidade())
            {
                MessageBox.Show("Atualizado com exito!");
            }
            else
                MessageBox.Show("Erro na Atualização");
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            Modalidade modalidade = new Modalidade(Convert.ToString(comboBox1.SelectedItem));
            MySqlDataReader r = modalidade.consultarModalidade();
            if (r.Read())
            {
                txtPreco.Text = r["precoModalidade"].ToString();
                txtQtdeAl.Text = r["qtdeAlunos"].ToString();
                txtQtdeAu.Text = r["qtdeAulas"].ToString();
            }
            DAO_Conexao.con.Close();
        }
    }
}
