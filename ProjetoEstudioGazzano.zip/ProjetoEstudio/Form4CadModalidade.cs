﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estudio
{
    public partial class Form4CadModalidade : Form
    {
        public Form4CadModalidade()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Modalidade modalidade = new Modalidade(txtDescricao.Text, float.Parse (txtPreco.Text), int.Parse(txtQtdeAl.Text), int.Parse (txtQtdeAula.Text));
            if (modalidade.cadastrarModalidade())
                MessageBox.Show("Cadastro realizado com sucesso");
            else
                MessageBox.Show("Erro no cadastro");
        }
    }
}
