﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estudio
{
    class Modalidade
    {

        private string Descricao;
        private float Preco;
        private int qntdAluno, qntdAulas;

        public string Descricao1 { get => Descricao; set => Descricao = value; }
        public float Preco1 { get => Preco; set => Preco = value; }
        public int QntdAluno { get => QntdAluno1; set => QntdAluno1 = value; }
        public int QntdAluno1 { get => qntdAluno; set => qntdAluno = value; }

        public Modalidade(string descricao, float preco, int qntdAluno, int qntdAulas) { }

      
     


















    }
}
